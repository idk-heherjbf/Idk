
import sys
import os
import hashlib
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import sqlite3
import json
from model.architecture import Seq2SeqTransformer
from tokenizers import Tokenizer



# Load tokenizer (fix path for script location)
TOKENIZER_PATH = os.path.join(os.path.dirname(__file__), "../tokenizer/tokenizer.json")
TOKENIZER_PATH = os.path.abspath(TOKENIZER_PATH)
tokenizer = Tokenizer.from_file(TOKENIZER_PATH)
vocab_size = tokenizer.get_vocab_size()


# Model save/load paths
MODEL_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "../model/model.pt"))
META_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "../model/model_meta.json"))
DATA_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "../data/cleaned_shell_logs.txt"))


# Hyperparameters
BATC_SIZE = 32
SRC_SEQ_LEN = 64  # question length
TGT_SEQ_LEN = 64  # answer length
EPOCHS = 30
LR = 1e-4
MODEL_DIM = 256
NHEAD = 8



# SQLite setup (use absolute path)
MEMORY_DB_PATH = os.path.join(os.path.dirname(__file__), "../memory/training_trace.db")
MEMORY_DB_PATH = os.path.abspath(MEMORY_DB_PATH)
conn = sqlite3.connect(MEMORY_DB_PATH)
cursor = conn.cursor()
cursor.execute("""
CREATE TABLE IF NOT EXISTS trace (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    input TEXT,
    trait TEXT,
    loss REAL
)
""")
conn.commit()


# Dataset

# Dataset for Q&A (seq2seq)
class QADataset(Dataset):
    def __init__(self, path):
        self.samples = []
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"): continue
                if "?" in line and "?" != line[0]:
                    parts = line.split("?", 1)
                    question = parts[0].strip() + "?"
                    answer = parts[1].strip()
                    if answer.startswith("A ") or answer.startswith("a "):
                        answer = answer[2:].strip()
                    if answer:
                        q_ids = tokenizer.encode(question).ids[:SRC_SEQ_LEN-1]
                        a_ids = tokenizer.encode(answer).ids[:TGT_SEQ_LEN-2]
                        # Add BOS/EOS tokens if tokenizer supports, else use 1/2
                        a_ids = [7] + a_ids + [8]  # 7=<bos>, 8=<eos>
                        q_ids += [0] * (SRC_SEQ_LEN - len(q_ids))
                        a_ids += [0] * (TGT_SEQ_LEN - len(a_ids))
                        self.samples.append((q_ids, a_ids))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        src, tgt = self.samples[idx]
        return torch.tensor(src, dtype=torch.long), torch.tensor(tgt, dtype=torch.long)

# Utility: hash file
def hash_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(8192)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()




# Model
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = Seq2SeqTransformer(vocab_size, d_model=MODEL_DIM, nhead=NHEAD).to(device)
optimizer = torch.optim.Adam(model.parameters(), lr=LR)
criterion = nn.CrossEntropyLoss(ignore_index=0)

# Check for existing model and metadata

import os
import json
train_data_hash = hash_file(DATA_PATH)
model_exists = os.path.exists(MODEL_PATH) and os.path.exists(META_PATH)
should_train = True

# Force retrain if vocab size changes (model/tokenizer update)
if model_exists:
    try:
        with open(META_PATH, "r") as f:
            meta = json.load(f)
        if meta.get("train_data_hash") == train_data_hash:
            model.load_state_dict(torch.load(MODEL_PATH, map_location=device))
            print("Loaded trained model from disk. Skipping retraining.")
            should_train = False
        else:
            print("Training data changed. Retraining model.")
    except Exception as e:
        print(f"Model/tokenizer mismatch or error: {e}\nDeleting old model and retraining.")
        if os.path.exists(MODEL_PATH):
            os.remove(MODEL_PATH)
        if os.path.exists(META_PATH):
            os.remove(META_PATH)
        should_train = True


if should_train:
    dataset = QADataset(DATA_PATH)
    loader = DataLoader(dataset, batch_size=BATC_SIZE, shuffle=True)
    for epoch in range(EPOCHS):
        for batch_idx, (src, tgt) in enumerate(loader):
            src, tgt = src.to(device), tgt.to(device)
            tgt_input = tgt[:, :-1]
            tgt_output = tgt[:, 1:]
            logits = model(src, tgt_input)
            loss = criterion(logits.reshape(-1, vocab_size), tgt_output.reshape(-1))
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            # Log to SQLite only every 100 batches
            if batch_idx % 100 == 0:
                cursor.execute("INSERT INTO trace (input, trait, loss) VALUES (?, ?, ?)",
                               (json.dumps(src[0].tolist()), "Q&A", float(loss.item())))
                conn.commit()
        print(f"Epoch {epoch+1}/{EPOCHS} - Loss: {loss.item():.4f}")
    # Save model and metadata
    torch.save(model.state_dict(), MODEL_PATH)
    with open(META_PATH, "w") as f:
        json.dump({"train_data_hash": train_data_hash}, f)
    print(f"Model saved to {MODEL_PATH}")

conn.close()
