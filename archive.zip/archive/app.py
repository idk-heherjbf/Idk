from fastapi import Body
# ...existing code...

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import subprocess
import os
import torch
import json
from archive.model.architecture import Seq2SeqTransformer
from tokenizers import Tokenizer

# ...existing code...
app = FastAPI()
# ...existing code...

# Greedy decoding for seq2seq Q&A
def generate_answer(question, max_len=64):
    model.eval()
    q_ids = tokenizer.encode(question).ids[:63]
    q_ids += [0] * (64 - len(q_ids))
    src = torch.tensor([q_ids], dtype=torch.long).to(device)
    tgt = torch.tensor([[7]], dtype=torch.long).to(device)  # 7 = <bos>
    output_ids = []
    for _ in range(max_len):
        with torch.no_grad():
            logits = model(src, tgt)
            next_token = torch.argmax(logits[0, -1], dim=-1).item()
    if next_token == 8 or next_token == 0:  # 8 = <eos>, 0 = <pad>
            break
        output_ids.append(next_token)
        tgt = torch.cat([tgt, torch.tensor([[next_token]], dtype=torch.long).to(device)], dim=1)
    return tokenizer.decode(output_ids)

@app.post("/api/ask")
async def api_ask(data: dict = Body(...)):
    user_input = data.get("input", "")
    if not model or not tokenizer:
        return JSONResponse({"error": "Model not loaded. Please train first."}, status_code=400)
    output = generate_answer(user_input)
    return JSONResponse({"input": user_input, "output": output})

# Serve static files (for frontend)
app.mount("/static", StaticFiles(directory="static"), name="static")

MODEL_PATH = "archive/model/model.pt"
META_PATH = "archive/model/model_meta.json"
TOKENIZER_PATH = "archive/tokenizer/tokenizer.json"

tokenizer = None
model = None
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
vocab_size = None

def load_model():
    global model, tokenizer, vocab_size
    tokenizer = Tokenizer.from_file(TOKENIZER_PATH)
    vocab_size = tokenizer.get_vocab_size()
    model = Seq2SeqTransformer(vocab_size).to(device)
    if os.path.exists(MODEL_PATH):
        model.load_state_dict(torch.load(MODEL_PATH, map_location=device))
        model.eval()
        return True
    return False

# Load model at startup if available
load_model()

@app.get("/", response_class=HTMLResponse)
def index():
    with open("static/index.html") as f:
        html = f.read()
    return HTMLResponse(content=html, status_code=200)

@app.post("/train")
def train():
    # Run the training script
    result = subprocess.run(["python3", "archive/training/train.py"], capture_output=True, text=True)
    # Reload model after training
    load_model()
    return JSONResponse({"stdout": result.stdout, "stderr": result.stderr, "returncode": result.returncode})

@app.post("/test")
async def test(request: Request):
    data = await request.json()
    user_input = data.get("input", "")
    if not model or not tokenizer:
        return JSONResponse({"error": "Model not loaded. Please train first."}, status_code=400)
    output = generate_answer(user_input)
    return JSONResponse({"input": user_input, "output": output})

@app.post("/reload")
def reload_model():
    loaded = load_model()
    if loaded:
        return JSONResponse({"result": "Model reloaded from disk."})
    else:
        return JSONResponse({"error": "Model file not found. Please train first."}, status_code=400)
